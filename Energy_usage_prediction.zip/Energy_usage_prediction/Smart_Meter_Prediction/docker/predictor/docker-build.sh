#!/bin/bash 
docker build  -f Dockerfile.predictor -t predictor_docker:latest .



