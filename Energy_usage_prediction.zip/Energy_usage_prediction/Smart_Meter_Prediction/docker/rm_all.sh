#!/bin/bash
docker rm -f hydro
docker rm -f predictor
docker rm -f influxdb
docker rm -f grafana
docker rm -f chronograf
