 docker run -it -p 5000:5000 -e USERNAME='' -e CONTRACT='' -e PASSWORD='' --name hydro --entrypoint /bin/bash hydro_docker 

